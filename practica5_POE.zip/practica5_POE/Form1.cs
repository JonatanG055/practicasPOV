﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica5_POE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularEdad_Click(object sender, EventArgs e)
        {
            // Declarar las variables 
            DateTime fechaNacimiento = dtpFechaNacimiento.Value;
            DateTime fechaActual  = DateTime.Now;

            //Realizar operación
            int edad = fechaActual.Year - fechaNacimiento.Year;


            if (fechaActual < fechaNacimiento.AddYears(edad))
            {
                edad--;

            }
            MessageBox.Show("Su edad es: " + edad);


            if (edad < 11)
            {
                MessageBox.Show("Usted es un niño, posee " + edad + " años");
            }
             else if (edad <= 11 && edad >= 18) 
            {
                MessageBox.Show("Usted es un adolecente, posee " + edad + " años");
            }
             else if (edad > 18 && edad >= 26)
            {
                MessageBox.Show("Usted es un joven, posee " + edad + " años");
            }
            else if ( edad > 26)
            {
                MessageBox.Show("Usted es un adulto, posee " + edad + " años");
            }


        }

    }
}
