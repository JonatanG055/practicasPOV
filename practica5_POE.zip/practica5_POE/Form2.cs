﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica5_POE
{
    public partial class Form2 : Form
    {
        List<Producto> listaProductos = new List<Producto>();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            ActualizarDataGridview();
        }

        public void ActualizarDataGridview()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listaProductos;
        }

        public void LimpiarControles()
        {
            txtNameProducto.Clear();
            txtPrecioProducto.Clear();
            txtExistenciasProducto.Clear();
            txtNameProducto.Focus();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            string nombre = txtNameProducto.Text;
            decimal precio = decimal.Parse(txtPrecioProducto.Text);
            int existencias = int.Parse(txtExistenciasProducto.Text);

            Producto nuevoProducto = new Producto (nombre, precio, existencias);
            listaProductos.Add(nuevoProducto);

            ActualizarDataGridview();
            LimpiarControles();
        }
    }
}
