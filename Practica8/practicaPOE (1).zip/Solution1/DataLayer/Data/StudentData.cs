﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataLayer.Data
{
    public class StudentData
    {
        Conection _connection = new Conection();
        SqlDataReader _reader;
        SqlCommand _command = new SqlCommand();
        DataTable studentTable = new DataTable();

        public DataTable GetAllStudents()
        {
            _command.Connection = _connection.OpenConnection();
            _command.CommandText = "SELECT * from alumnos";
            _command.CommandType = CommandType.Text;

            _reader = _command.ExecuteReader();
            studentTable.Load( _reader );

            _connection.CloseConnection();

            return studentTable;
        }

        public void AddStudents(string name, string code, string number, string city)
        {
            _command.Connection = _connection.OpenConnection();
            _command.CommandText = "INSERT INTO alumnos VALUES (@name,@code, @number, @city)";
            _command.CommandType = CommandType.Text;

            _command.Parameters.AddWithValue("name", name);
            _command.Parameters.AddWithValue("code", code);
            _command.Parameters.AddWithValue ("number", number);
            _command.Parameters.AddWithValue("city", city);

            _command.ExecuteNonQuery();
            //LIMPIAMOS LOS DATOS
            _command.Parameters.Clear();
            //CERRAMOS LA CONECCION
            _connection.CloseConnection();

        }
        public void UpdateStudents(int id, string name, string code, string number, string city)
        {
            _command.Connection = _connection.OpenConnection();
            _command.CommandText = "UDTAPE alumnos set nombre_alumno = @name,"+
                "codigo_alumno = @code, telefono = @number, ciudad_alumno = @city,"+
                "WHERE id_alumno = @id";
            _command.CommandType = CommandType.Text;

            _command.Parameters.AddWithValue("name", name);
            _command.Parameters.AddWithValue("code", code);
            _command.Parameters.AddWithValue("number", number);
            _command.Parameters.AddWithValue("city", city);
            _command.Parameters.AddWithValue("id", id);

            _command.ExecuteNonQuery();
            //LIMPIAMOS LOS DATOS
            _command.Parameters.Clear();
            //CERRAMOS LA CONECCION
            _connection.CloseConnection();

        }
        public void DeleteStudents(int id)
        {
            _command.Connection = _connection.OpenConnection();
            _command.CommandText = "DELETE FROM alumnos WHERE id_alumnos = @id";
            _command.CommandType = CommandType.Text;

            _command.ExecuteNonQuery();
            //LIMPIAMOS LOS DATOS
            _command.Parameters.Clear();
            //CERRAMOS LA CONECCION
            _connection.CloseConnection();

        }
    }
}
