﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DataLayer.Data
{
    public class Conection
    {
        private SqlConnection _connection  = new SqlConnection(@"Data Source=LAPTOP-LMRRKBF2\SQLEXPRESS;Initial Catalog=Alumnos;Integrated Security=True");

        public SqlConnection OpenConnection()
        { 
            if(_connection.State == ConnectionState.Closed)
            {
                _connection.Open();   
            }
            return _connection;
        }

        public SqlConnection CloseConnection()
        {
            if (_connection.State == ConnectionState.Open)
            {
                _connection.Close();
            }
            return _connection;
        }
        
    }
}
